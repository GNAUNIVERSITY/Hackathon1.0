import './components/CSS/App.css'
import Login from "./components/login";
import {Routes,Route} from 'react-router-dom'
import Register from './components/register';
import Sos from './components/Sos';
import Contact from './components/contacts'
import { useEffect, useState } from 'react';
function App() {
  const [user,setUser] = useState({})

  useEffect(()=>{
    console.log(user)
  },[user])
  return (
    <div className="App">
      <div className="Header"><h1>SOS</h1></div>
      <Routes>
        <Route exact path='/'element={<Login setUser={setUser} />}/>
        <Route path='/register' element={<Register/>}/>
        <Route path='/sos' element={<Sos user={user}/>}/>
        <Route path='/contact' element={<Contact user={user}/>} />
      </Routes>
    </div>
  );
}

export default App;
