import React, { useState,useEffect } from 'react'
import './CSS/login.css'
import {useNavigate} from 'react-router-dom'


function Login({setUser}) {
    const [data,setData]=useState({
        username:'',
        pass:''
    })
    const [records,setRecord]=useState([]);
    const nav=useNavigate();
    

    useEffect(()=>{
        const getRecords=async()=>{
          const response = await fetch(`http://localhost:5000/api/`);
    
          if(!response.ok){
            window.alert(`An err has occurred : ${response.statusText}`);
            return;
          }
          const records=await response.json();
          setRecord(records);
          console.log(records);
        }

        getRecords()
        return;
      },[records.length])

      const getData=()=>{
        const obj=records.find((o)=>o.username===data.username)
        
        
        if(obj===undefined)
            window.alert("user doesnot exist")
        else if(obj.pass!=data.pass){
            window.alert("wrong password!!")
        }
        else{
            console.log(obj)
            setUser(obj)
            nav('/sos')
        }
        
        
      }


    const updateData=(value)=>{
        return setData((prev)=>{
            return {...prev,...value}
        })

      }
  return (
    <div className='main'>
        <div className="content">
            <h1>Login</h1>
            <div className='area'>
                <div className="username">
                    <h3>USERNAME: </h3>
                    <input type="text" className='inp' onChange={(e)=>{
                        updateData({username:e.target.value})
                    }}/>
                </div>
                <div className="pass">
                    <h3>PASSWORD: </h3>
                    <input type="password" className='inp' onChange={(e)=>{
                        updateData({pass:e.target.value})
                    }}/>
                </div>
                <div className='btn'>
                    <input type="button" value="Login" onClick={()=>{
                        getData()
                        console.log(data)
                    }}/>
                    <input type="button" value="register" onClick={()=>{
                        setData({username:'',pass:''})
                        nav('/register')
                    }} />
                </div>
            </div>
        </div>
    </div>
  )
}

export default Login

//14 
//times 