import React from 'react'
import './CSS/contacts.css'

function contacts({user}) {
    var id=user._id;
    var cont=user.contacts;
    var cont1=8434622426
    var cont2=9199995704
    const Content=(props)=>(
        <tr>
          <td>{props.record.title}</td>
          <td>{props.record.pass}</td>
          <td>
            <input type="button" value='DELETE' onClick={()=>{
              props.deleteRecord(props.record._id)
            }} />
          </td>
          <td>
            <input type="button" value='EDIT' onClick={()=>{
              props.nav('/edit')
            }} />
          </td>
        </tr>
    )

    const list=()=>{
        return cont.map((co)=>{
            return(
                <Content co={co}/>
            )
        })
    }

  return (
    <div className='container'>
        <div className="innerForm">
            <h2>Emergency Contacts</h2>
            <div className='frm'>
                <input type='text' className='contacts' id="" />
                <input type="button" value='+' className='btn2' />
            </div>
            <div className="tab">
            <table className='table' style={{marginTop:20}}>
                <thead className='thead'>
                    <tr>
                        <th>Contacts</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>{cont1}</td>
                    </tr>
                    <tr>
                        <td>{cont2}</td>
                    </tr>
                    <tr>
                        <td>123456</td>
                    </tr>
                </tbody>
            </table>
        </div>
        
        </div>

        
    </div>
  )
}

export default contacts