import React, { useEffect, useState } from 'react'
import { Map, Marker } from 'pigeon-maps'
import axios from 'axios'
import './CSS/sos.css'
import {useNavigate} from 'react-router-dom'


const Api_key = `3bdb8ccccbc9a2bc4a2a07e4acdb6411`


function Sos({ user }) {
const nav=useNavigate()

    var [lat, setLat] = useState('');
    var [long, setLong] = useState('');

    const [Location, setLocation] = useState({})
    useEffect(() => {
        console.log(user)
        navigator.geolocation.getCurrentPosition((pos) => {
            setLat(pos.coords.latitude)
            setLong(pos.coords.longitude)
            console.log(lat, long)
        })

        let finalApi = `https://api.openweathermap.org/data/2.5/weather?lat=31.2773616&lon=75.7792062&appid=${Api_key}`


        axios.get(finalApi)
            .then((response) => {
                setLocation(response.data)
                console.log(response.data)
            })




    }, [])
    return (
        <div className='contents'>
            <div className="head">
                <h1>Welcome {user.name}</h1>
                <h3>Your current location is {Location.name}</h3>
                <div className="">
                <div className="map">
                    <Map height={300} width={500} defaultCenter={[31.274727, 75.7720215]} defaultZoom={13}>
                        <Marker width={20} anchor={[lat, long]} />
                    </Map>
                </div>

                <div className="btnn">
                    <div className="btn1">
                        <input type="button" value="contacts" className='bub' onClick={()=>{
                            nav('/contact')
                        }} />

                    </div>
                    <div className="btn1">
                        <input type="button" value="SOS" id="sos" className='bub' />

                    </div>
                    <div className="btn1">
                        <input type="button" value="Alert TEXT" className='bub' />

                    </div>
                </div>
                </div>

            </div>

        </div>
    )
}

export default Sos