import React from 'react'
import { useEffect, useState } from 'react'
import {useNavigate} from 'react-router-dom'
function Register() {
    const nav=useNavigate()

    const [data, setData] = useState({
        name: '',
        email:'',
        username:'',
        mob:'',
        pass: '',
        contacts:[]
      })

      const updateData=(value)=>{
        return setData((prev)=>{
            return {...prev,...value}
        })
      }

      const onSave=async(e)=>{
        e.preventDefault();

        const newData={...data};
        await fetch('http://localhost:5000/api/add',{
            method:'POST',
            headers:{
                "Content-Type":"application/json",
            },
            body:JSON.stringify(newData)
        })
        .catch(er=>{
            window.alert(er)
            return
        })
        console.log(newData)
        setData({
            name: '',
            email:'',
            username:'',
            mob:'',
            pass: '',
            contacts:[]
        })
        nav('/')
       
      }

  return (


    <div className='main'>
        <div className="content">
            <h1>Register</h1>
            <div className='area'>
                <div className="name">
                    <h3>NAME: </h3>
                    <input type="text"className='inp' onChange={(e)=>{
                        updateData({name:e.target.value})
                    }} />
                </div>
                <div className="email">
                    <h3>EMAIL: </h3>
                    <input type="text" className='inp'onChange={(e)=>{
                        updateData({email:e.target.value})
                    }}/>
                </div>
                <div className="username">
                    <h3>USERNAME: </h3>
                    <input type="text" className='inp' onChange={(e)=>{
                        updateData({username:e.target.value})
                    }}/>
                </div>
                <div className="pass">
                    <h3>PASSWORD: </h3>
                    <input type="password" className='inp'onChange={(e)=>{
                        updateData({pass:e.target.value})
                    }}/>
                </div>
                <div className="mobile">
                    <h3>MOBILE NO.: </h3>
                    <input type="text" className='inp' onChange={(e)=>{
                        updateData({mob:e.target.value})
                    }}/>
                </div>
                <div className='btn'>
                    <input type="button" value="create account" onClick={onSave} />
                </div>
            </div>
        </div>
    </div>
  )
}

export default Register