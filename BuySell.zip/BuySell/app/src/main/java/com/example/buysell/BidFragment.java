package com.example.buysell;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.textfield.TextInputEditText;

import java.util.Objects;

public class BidFragment extends Fragment {
    TextInputEditText etAmount;
    Button btnSend;


    @Override

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_bid, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        etAmount = view.findViewById(R.id.etAmount);

        btnSend = view.findViewById(R.id.btnSendEmail);
        btnSend.setOnClickListener(view1 -> {
            String amount = Objects.requireNonNull(etAmount.getText()).toString().trim();
            if (!amount.isEmpty()) {
                sendEmail(amount);
            }
        });
    }

    private void sendEmail(String amount){

        String message = "Bid amount "+amount;
        String subject = "Bid for crop";
        assert getArguments() != null;

        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{"youthoobfree@gmail.com"});
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
        emailIntent.putExtra(Intent.EXTRA_TEXT, message);
        emailIntent.setType("message/rfc822");

        try {
            startActivity(Intent.createChooser(emailIntent, "Send mail..."));
        } catch (android.content.ActivityNotFoundException ex) {
            Toast.makeText(requireContext(), "There is no email client installed.", Toast.LENGTH_SHORT).show();
        }
    }
}