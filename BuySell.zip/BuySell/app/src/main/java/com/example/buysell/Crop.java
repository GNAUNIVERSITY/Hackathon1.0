package com.example.buysell;

public class Crop {
    private String title;
    private String desc;
    private String price;
    private String quantity;
    private String contact;

    public Crop(){

    }
    public Crop(String title, String desc, String price,String quantity,String contact) {
        this.title = title;
        this.desc = desc;
        this.price = price;
        this.quantity=quantity;
        this.contact = contact;
    }

    public String getTitle() {
        return title;
    }

    public String getDesc() {
        return desc;
    }

    public String getPrice() {
        return price;
    }

    public String getQuantity() {
        return quantity;
    }

    public String getContact() {
        return contact;
    }
}
