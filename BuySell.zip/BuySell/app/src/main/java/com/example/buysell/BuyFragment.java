package com.example.buysell;

import android.app.Dialog;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.google.android.material.progressindicator.CircularProgressIndicator;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class BuyFragment extends Fragment implements BuyAdapter.Callback {

    private RecyclerView recyclerView;
    private  FirebaseDatabase database;
    private BuyAdapter adapter;
    private DatabaseReference dbRef;
    private FirebaseAuth auth;
    private CircularProgressIndicator progressBar;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_buy, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        recyclerView = view.findViewById(R.id.rvBuy);
        database = FirebaseDatabase.getInstance();
        dbRef = FirebaseDatabase.getInstance().getReference("Crops");
        progressBar = view.findViewById(R.id.pbBuy);
        getData();

    }

    private void getData(){
        ArrayList<Crop> list = new ArrayList<>();

        ValueEventListener valueEventListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()){
                    for(DataSnapshot dataSnapshot : snapshot.getChildren()){
                        Crop item = dataSnapshot.getValue(Crop.class);
                        if(item!=null && !list.contains(item)){
                            list.add(item);
                        }
                    }
                    setRecyclerView(list);
                }else{
                    Toast.makeText(requireContext(), "No data available", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(requireContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        };

        dbRef.orderByKey().addValueEventListener(valueEventListener);
    }

    private void setRecyclerView(ArrayList<Crop> list){
        adapter = new BuyAdapter(list,this);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        recyclerView.hasFixedSize();
        progressBar.hide();
    }

    @Override
    public void onClick(String email) {
        Bundle bundle = new Bundle();
        bundle.putString("email",email);
        requireActivity().getSupportFragmentManager().beginTransaction().replace(R.id.container_home,BidFragment.class,bundle).addToBackStack("BUYFRAGMENT").commit();
    }
}