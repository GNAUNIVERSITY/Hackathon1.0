package com.example.buysell;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.MenuRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Objects;


public class SellFragment extends Fragment {

    MaterialButton btnAdd;
    CardView cvSelectCrop;
    TextInputLayout tilQuantity;
    TextInputLayout tilPrice;
    TextInputEditText etQuantity;
    TextInputEditText etPrice;
    FirebaseDatabase database;
    DatabaseReference reference;
    TextView tvDropDown;
    FirebaseAuth auth;
    String price;
    String quantity;
    String cropName;
    String email;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_sell, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        tilPrice = view.findViewById(R.id.tilPrice);
        tilQuantity = view.findViewById(R.id.tilQuantity);
        etPrice = view.findViewById(R.id.etPrice);
        database = FirebaseDatabase.getInstance();
        reference = database.getReference();
        etQuantity = view.findViewById(R.id.etQuantity);
        cvSelectCrop = view.findViewById(R.id.cvDropDown);
        btnAdd = view.findViewById(R.id.btnAdd);
        tvDropDown = view.findViewById(R.id.tvSelectCrop);
        auth = FirebaseAuth.getInstance();

        cvSelectCrop.setOnClickListener(view1 -> {
            showMenu(view1, R.menu.crop_items);
        });

        btnAdd.setOnClickListener(view1 -> {
            email = Objects.requireNonNull(auth.getCurrentUser()).getEmail();
            cropName = tvDropDown.getText().toString();
            quantity = Objects.requireNonNull(etQuantity.getText()).toString();
            price = Objects.requireNonNull(etPrice.getText()).toString();

            if (!cropName.isEmpty() && !quantity.isEmpty() && !price.isEmpty() && !tvDropDown.getText().toString().equals("Select Crop")) {
                Crop item = new Crop(cropName, " ", price, quantity, email);
                addData(item);
            } else {
                Toast.makeText(requireContext(), "fail", Toast.LENGTH_SHORT).show();
            }

        });
    }

    private void showMenu(View v, @MenuRes int menuRes) {
        PopupMenu popup = new PopupMenu(requireContext(), v);
        popup.getMenuInflater().inflate(menuRes, popup.getMenu());

        popup.setOnMenuItemClickListener(menuItem -> {
            int id = menuItem.getItemId();
            if (id == R.id.miRice) {
                tvDropDown.setText(menuItem.getTitle());
            } else if (id == R.id.miBarley) {
                tvDropDown.setText(menuItem.getTitle());
            } else if (id == R.id.miSugarcane) {
                tvDropDown.setText(menuItem.getTitle());
            } else if (id == R.id.miWheat) {
                tvDropDown.setText(menuItem.getTitle());
            }
            return true;
        });
        popup.setOnDismissListener(PopupMenu::dismiss);
        // Show the popup menu.
        popup.show();
    }

    private void addData(Crop item) {
        String userId = Objects.requireNonNull(auth.getCurrentUser()).getUid();

        reference.child("Crops").push().setValue(item).addOnSuccessListener(unused ->
                Toast.makeText(requireContext(), "Successfully added", Toast.LENGTH_SHORT).show())
                .addOnFailureListener(e ->
                        Toast.makeText(requireContext(), e.getMessage(), Toast.LENGTH_SHORT).show());
    }
}