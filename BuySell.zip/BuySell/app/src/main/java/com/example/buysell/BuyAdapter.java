package com.example.buysell;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class BuyAdapter extends RecyclerView.Adapter<BuyAdapter.BuyViewHolder> {
    ArrayList<Crop> list;
    Callback listener;

    public BuyAdapter(ArrayList<Crop> list,Callback listener) {
        this.list = list;
        this.listener=listener;
    }

    @NonNull
    @Override
    public BuyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.buy_items, parent, false);
        return new BuyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BuyViewHolder holder, int position) {
        Crop currentItem = list.get(position);
        holder.title.setText(currentItem.getTitle());
        holder.desc.setText(currentItem.getDesc());
        String pricee = "Rs. "+currentItem.getPrice()+"/1000Kg";
        String quantitty = currentItem.getQuantity()+"Kg";
        holder.quantity.setText(quantitty);
        holder.price.setText(pricee);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    class BuyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

        TextView title, desc, price,quantity;

        public BuyViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.tvCropName);
            desc = itemView.findViewById(R.id.tvDesc);
            price = itemView.findViewById(R.id.tvPrice);
            quantity=itemView.findViewById(R.id.tvQuantity);
        }

        {
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            listener.onClick(list.get(getAdapterPosition()).getContact());
        }
    }

    interface Callback{
        void onClick(String email);
    }
}
