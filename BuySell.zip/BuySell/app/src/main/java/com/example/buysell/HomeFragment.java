package com.example.buysell;

import static androidx.navigation.Navigation.findNavController;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class HomeFragment extends Fragment {


    private ImageButton ibBuy;
    private ImageButton ibSell;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ibBuy = view.findViewById(R.id.ivBuy);
        ibSell = view.findViewById(R.id.ivSell);

        ibBuy.setOnClickListener(view1 -> {
            requireActivity()
                    .getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.container_home, BuyFragment.class, null,"Buy")
                    .addToBackStack("Home")
                    .commit();
        });

        ibSell.setOnClickListener(view1 -> {
            requireActivity()
                    .getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.container_home, SellFragment.class, null,"Sell")
                    .addToBackStack("Home")
                    .commit();
        });
    }
}