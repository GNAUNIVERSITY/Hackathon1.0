<html>
<head><link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
<style>
body {
  background-image: url("https://source.unsplash.com/720x600/?community,lbtq,rainbow heart");
}
</style>
</head>
<title>Login Link Me
</title>
<body>

<center>

<form>
<section class="text-gray-600 body-font">
<font size=100px>
 <div class="rainbow-text" style="text-align:center">
	<span class="block-line"><span><span style="color:#ff0000;">L</span><span style="color:#ff3c00;">i</span><span style="color:#ff7300;">n</span><span style="color:#ffaa00;">k</span></span><span><span style="color:#ffe500;">M</span><span style="color:#e1ff00;">E</span></span></span>
</font>
    <div class="lg:w-2/6 md:w-1/2 bg-gray-100 rounded-lg p-8 flex flex-col md:ml-auto w-full mt-10 md:mt-0">
      <h2 class="text-gray-900 text-lg font-medium title-font mb-5">Login</h2>
      <div class="relative mb-4">
        <label for="full-name" class="leading-7 text-sm text-gray-600">Email id</label>
        <input type="email" id="full-name" name="full name" class="w-full bg-white rounded border border-gray-300 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 text-base outline-none text-gray-700 py-1 px-3 leading-8 transition-colors duration-200 ease-in-out" placeholder="Email id">
      </div>
      <div class="relative mb-4">
        <label for="password" class="leading-7 text-sm text-gray-600">Password</label>
        <input type="password" id="password" name="password" class="w-full bg-white rounded border border-gray-300 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 text-base outline-none text-gray-700 py-1 px-3 leading-8 transition-colors duration-200 ease-in-out" placeholder="Password">
      </div>
	  <a href="server.php" class="rainbow-button" alt="Button"></a>
      <button class="text-white bg-indigo-500 border-0 py-2 px-8 focus:outline-none hover:bg-indigo-600 rounded text-lg">Login</button>
      <p class="text-xs text-gray-500 mt-3"><b>did'nt have an account</b></p>
	  <a href ="signup.php" class="text-white bg-pink-500 border-0 py-2 px-8 focus:outline-none hover:bg-pink-600 rounded text-lg" align=center>Sign up<a>
    </div>
  </div>
</section>

</form>
</center>

</body>
</html>